import{a}from"./chunk-HI23OWUU.js";import"./chunk-X6YOYRVK.js";export default a();
